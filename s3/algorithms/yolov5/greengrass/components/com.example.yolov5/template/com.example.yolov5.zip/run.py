# -*- coding: utf-8 -*-
import json
import os
import sys
import warnings
import io
import uuid
import os
import imghdr

import argparse
import time
from pathlib import Path

FILE = Path(__file__).resolve()
ROOT = FILE.parents[0]  # YOLOv5 root directory
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))  # add ROOT to PATH
ROOT = Path(os.path.relpath(ROOT, Path.cwd()))  # relative

import torch
import torch.backends.cudnn as cudnn

from models.experimental import attempt_load
from utils.datasets import LoadStreams, LoadImages
from utils.general import check_img_size, check_requirements, check_imshow, non_max_suppression, apply_classifier, \
    scale_coords, xyxy2xywh, strip_optimizer, set_logging, increment_path
from utils.plots import colors
from utils.torch_utils import select_device, time_sync

import time
import traceback

import awsiot.greengrasscoreipc
import awsiot.greengrasscoreipc.client as client
from awsiot.greengrasscoreipc.model import (
    SubscribeToTopicRequest,
    SubscriptionResponseMessage,
    UnauthorizedError
)

from awsiot.greengrasscoreipc.model import (
    PublishToTopicRequest,
    PublishMessage,
    BinaryMessage,
    UnauthorizedError
)         

ipc_in_client = awsiot.greengrasscoreipc.connect()
ipc_out_client = awsiot.greengrasscoreipc.connect()

TIMEOUT = 10
source = ROOT / 'data/images'
weights = ROOT / 'models/best.pt'
imgsz = 640
conf_thres = 0.02
iou_thres = 0.45
max_det = 1000
device = 'cpu'
classes = None
agnostic_nms = False
augment = False
half = False

def init(weights,  # model.pt path(s)
           imgsz,  # inference size (pixels)
           conf_thres,  # confidence threshold
           iou_thres,  # NMS IOU threshold
           max_det,  # maximum detections per image
           device='',  # cuda device, i.e. 0 or 0,1,2,3 or cpu
           view_img=False,  # show results
           save_txt=False,  # save results to *.txt
           save_conf=False,  # save confidences in --save-txt labels
           save_crop=False,  # save cropped prediction boxes
           nosave=False,  # do not save images/videos
           classes=None,  # filter by class: --class 0, or --class 0 2 3
           agnostic_nms=False,  # class-agnostic NMS
           augment=False,  # augmented inference
           update=False,  # update all models
           project='runs/detect',  # save results to project/name
           exist_ok=False,  # existing project/name ok, do not increment
           line_thickness=3,  # bounding box thickness (pixels)
           hide_labels=False,  # hide labels
           hide_conf=False,  # hide confidences
           half=False,  # use FP16 half-precision inference
        ):
    # Initialize
    set_logging()
    device = select_device(device)
    half &= device.type != 'cpu'  # half precision only supported on CUDA

    # Load model
    model = attempt_load(weights, map_location=device)  # load FP32 model
    stride = int(model.stride.max())  # model stride
    imgsz = check_img_size(imgsz, s=stride)  # check image size
    names = model.module.names if hasattr(model, 'module') else model.names  # get class names
    if half:
        model.half()  # to FP16
        
    # Run inference
    if device.type != 'cpu':
        model(torch.zeros(1, 3, imgsz, imgsz).to(device).type_as(next(model.parameters())))  # run once
        
    return model, names

def detect(source=source):
    stride = int(model.stride.max())  # model stride
    
    try:
        dataset = LoadImages(source, img_size=imgsz, stride=stride)
    except:
        traceback.print_exc()

    t0 = time.time()
    for path, img, im0s, vid_cap, s in dataset:
        img = torch.from_numpy(img).to(device)
        img = img.half() if half else img.float()  # uint8 to fp16/32
        img /= 255.0  # 0 - 255 to 0.0 - 1.0
        if img.ndimension() == 3:
            img = img.unsqueeze(0)

        # Inference
        t1 = time_sync()
        pred = model(img, augment=augment)[0]

        # Apply NMS
        pred = non_max_suppression(pred, conf_thres, iou_thres, classes, agnostic_nms, max_det=max_det)
        t2 = time_sync()

        # Process detections
        result = []
        for i, det in enumerate(pred):  # detections per image
            p, s, im0, frame = path, '', im0s.copy(), getattr(dataset, 'frame', 0)

            p = Path(p)  # to Path
            s += '%gx%g ' % img.shape[2:]  # print string
            gn = torch.tensor(im0.shape)[[1, 0, 1, 0]]  # normalization gain whwh
            imc = im0  # for save_crop
            if len(det):
                # Rescale boxes from img_size to im0 size
                det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0.shape).round()

                # Print results
                for c in det[:, -1].unique():
                    n = (det[:, -1] == c).sum()  # detections per class
                    s += f"{n} {names[int(c)]}{'s' * (n > 1)}, "  # add to string

                # Write results
                for *xyxy, conf, cls in reversed(det):
                    xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()  # normalized xywh
                    line = (cls, *xywh)  # label format
                    line = ('%g ' * len(line)).rstrip() % line
                    result.append(line)

            # Print time (inference + NMS)
            print(f'{s}Done. ({t2 - t1:.3f}s)')

    print('result:', result)
    return result

def publish(message):
    topic = sys.argv[2]
    print('out topic : {0}'.format(topic))

    request = PublishToTopicRequest()
    request.topic = topic
    publish_message = PublishMessage()
    publish_message.binary_message = BinaryMessage()
    publish_message.binary_message.message = bytes(message, "utf-8")
    request.publish_message = publish_message
    operation = ipc_out_client.new_publish_to_topic()
    operation.activate(request)
    futureResponse = operation.get_response()

    try:
        futureResponse.result(TIMEOUT)
        print('Successfully published to topic: ' + topic)
    except concurrent.futures.TimeoutError:
        print('Timeout occurred while publishing to topic: ' + topic, file=sys.stderr)
    except UnauthorizedError as e:
        print('Unauthorized error while publishing to topic: ' + topic, file=sys.stderr)
        raise e
    except Exception as e:
        print('Exception while publishing to topic: ' + topic, file=sys.stderr)
        raise e

class StreamHandler(client.SubscribeToTopicStreamHandler):
    def __init__(self):
        super().__init__()

    def on_stream_event(self, event: SubscriptionResponseMessage) -> None:
        try:
            in_message = str(event.binary_message.message, "utf-8")
            print("Received new message: " + in_message)
            data = json.loads(in_message)
            mid = data['mid']
            source = data['source']
            result = detect(source)
            out_message = {}
            out_message['mid'] = mid
            out_message['result'] = result
            publish(json.dumps(out_message))
        except:
            traceback.print_exc()

    def on_stream_error(self, error: Exception) -> bool:
        print("Received a stream error.", file=sys.stderr)
        traceback.print_exc()
        return False  # Return True to close stream, False to keep stream open.

    def on_stream_closed(self) -> None:
        print('Subscribe to topic stream closed.')

def subscribe():
    topic = sys.argv[1]
    print('in topic : {0}'.format(topic))
    request = SubscribeToTopicRequest()
    request.topic = topic
    handler = StreamHandler()
    operation = ipc_in_client.new_subscribe_to_topic(handler)
    future = operation.activate(request)

    try:
        future.result(TIMEOUT)
        print('Successfully subscribed to topic: ' + topic)
    except concurrent.futures.TimeoutError as e:
        print('Timeout occurred while subscribing to topic: ' + topic, file=sys.stderr)
        raise e
    except UnauthorizedError as e:
        print('Unauthorized error while subscribing to topic: ' + topic, file=sys.stderr)
        raise e
    except Exception as e:
        print('Exception while subscribing to topic: ' + topic, file=sys.stderr)
        raise e

    # Keep the main thread alive, or the process will exit.
    while True:
        time.sleep(10)

    # To stop subscribing, close the operation stream.
    operation.close()

model, names = init(weights=weights, imgsz=imgsz, conf_thres=conf_thres, iou_thres=iou_thres, max_det=max_det, device=device, classes=classes, agnostic_nms=agnostic_nms, augment=augment, half=half)

subscribe()
