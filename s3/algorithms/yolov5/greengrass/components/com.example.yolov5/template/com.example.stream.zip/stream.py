import subprocess
import cv2
import uuid
import datetime
import sys
import os
import json
import threading
import copy

# rtmp_url = "rtmp://71.131.207.183/hls/opencv"

import time
import traceback

import awsiot.greengrasscoreipc
import awsiot.greengrasscoreipc.client as client
from awsiot.greengrasscoreipc.model import (
    SubscribeToTopicRequest,
    SubscriptionResponseMessage,
    UnauthorizedError
)

from awsiot.greengrasscoreipc.model import (
    PublishToTopicRequest,
    PublishMessage,
    BinaryMessage,
    UnauthorizedError
)

from awsiot.greengrasscoreipc.model import (
    IoTCoreMessage,
    QOS,
    SubscribeToIoTCoreRequest
)

ipc_in_client = awsiot.greengrasscoreipc.connect()
ipc_out_client = awsiot.greengrasscoreipc.connect()
stream_out_message = 'off'
target_stream = ''

print(sys.argv)
inference_result_topic = sys.argv[1]
inference_topic = sys.argv[2]
source_stream = sys.argv[3]
device_id = sys.argv[4]
notification_topic = sys.argv[5]
inference_type = sys.argv[6]
# iotcore_control_topic = sys.argv[7]

inference_count = len(inference_type.split(';'))
mid = ''

from pathlib import Path

FILE = Path(__file__).resolve()
ROOT = FILE.parents[0]  # YOLOv5 root directory
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))  # add ROOT to PATH
ROOT = Path(os.path.relpath(ROOT, Path.cwd()))  # relative

TIMEOUT = 10

# In my mac webcamera is 0, also you can set a video file name instead, for example "/home/user/demo.mp4"
print(source_stream)
path = source_stream
cap = cv2.VideoCapture(path)

# gather video info to ffmpeg
fps = int(cap.get(cv2.CAP_PROP_FPS))
width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

# command and params for ffmpeg
command = ['ffmpeg',
           '-y',
           '-f', 'lavfi',
           '-i', 'anullsrc=channel_layout=stereo:sample_rate=44100',
           '-f', 'rawvideo',   
           '-vcodec', 'rawvideo',
           '-pix_fmt', 'bgr24',
           '-s', "{}x{}".format(width, height),
           '-r', str(fps),
           '-i', '-',
           '-framerate', '30',
           '-c:v', 'h264_nvmpi',
           '-c:a', 'aac',
           '-shortest',
           '-f', 'flv',
           '-hls_list_size', '0',
           '-g', '5',
           target_stream]
    
# command = ['ffmpeg',
#            '-y',
#            '-f', 'lavfi',
#            '-i', 'anullsrc=channel_layout=stereo:sample_rate=44100',
#            '-f', 'rawvideo',   
#            '-vcodec', 'rawvideo',
#            '-pix_fmt', 'bgr24',
#            '-s', "{}x{}".format(width, height),
#            '-r', str(fps),
#            '-i', '-',
#            '-framerate', '30',
#            '-c:v', 'h264_nvmpi',
#            '-c:a', 'aac',
#            '-shortest',
#            '-f', 'flv',
#            '-hls_list_size', '0',
#            '-g', '5']

incompleted = True
outputList = []
condition_obj = threading.Condition()

def publish(message, topic):
    
    print('out topic : {0}'.format(topic))

    request = PublishToTopicRequest()
    request.topic = topic
    publish_message = PublishMessage()
    publish_message.binary_message = BinaryMessage()
    publish_message.binary_message.message = bytes(message, "utf-8")
    request.publish_message = publish_message
    operation = ipc_out_client.new_publish_to_topic()
    operation.activate(request)
    futureResponse = operation.get_response()

    try:
        futureResponse.result(TIMEOUT)
        print('Successfully published to topic: ' + topic)
    except concurrent.futures.TimeoutError:
        print('Timeout occurred while publishing to topic: ' + topic, file=sys.stderr)
    except UnauthorizedError as e:
        print('Unauthorized error while publishing to topic: ' + topic, file=sys.stderr)
        raise e
    except Exception as e:
        print('Exception while publishing to topic: ' + topic, file=sys.stderr)
        raise e

class StreamHandler(client.SubscribeToTopicStreamHandler):
    def __init__(self):
        super().__init__()

    def on_stream_event(self, event: SubscriptionResponseMessage) -> None:
        try:
            message = str(event.binary_message.message, "utf-8")
            print("Received new message: " + message)
            data = json.loads(message)
            global mid
            # mid = data['mid']
            # print("=====mid is:{0}, ======{1}".format(mid, data['mid']))
            # if mid == data['mid']:
            result = data['result']
            global outputList
            outputList.append(result)
            # print('output - {0}'.format(outputList))
            condition_obj.acquire()
            condition_obj.notify()
        except:
            traceback.print_exc()
        finally:
            condition_obj.release()

    def on_stream_error(self, error: Exception) -> bool:
        print("Received a stream error.", file=sys.stderr)
        traceback.print_exc()
        return False  # Return True to close stream, False to keep stream open.

    def on_stream_closed(self) -> None:
        print('Subscribe to topic stream closed.')

def subscribe():
    print('in topic : {0}'.format(inference_result_topic))
    request = SubscribeToTopicRequest()
    request.topic = inference_result_topic
    handler = StreamHandler()
    operation = ipc_in_client.new_subscribe_to_topic(handler)
    future = operation.activate(request)

    try:
        future.result(TIMEOUT)
        print('Successfully subscribed to topic: ' + inference_result_topic)
    except concurrent.futures.TimeoutError as e:
        print('Timeout occurred while subscribing to topic: ' + inference_result_topic, file=sys.stderr)
        raise e
    except UnauthorizedError as e:
        print('Unauthorized error while subscribing to topic: ' + inference_result_topic, file=sys.stderr)
        raise e
    except Exception as e:
        print('Exception while subscribing to topic: ' + inference_result_topic, file=sys.stderr)
        raise e

class IoTCoreStreamHandler(client.SubscribeToIoTCoreStreamHandler):
    def __init__(self):
        super().__init__()

    def on_stream_event(self, event: IoTCoreMessage) -> None:
        try:
            global stream_out_message
            global target_stream
            global p

            message = str(event.message.payload, "utf-8")

            stream_out_message = message

            # messageObj = json.loads(message)

            
            # if messageObj['action'] == 'on': 
            #     target_stream = messageObj['target']
            #     full_command = copy.copy(command)
            #     p = subprocess.Popen(full_command, stdin=subprocess.PIPE)
            #     stream_out_message = 'on'
            # else:
            #     target_stream = ''
            
            print(stream_out_message)
            # Handle message.
        except:
            traceback.print_exc()

    def on_stream_error(self, error: Exception) -> bool:
        # Handle error.
        return True  # Return True to close stream, False to keep stream open.

    def on_stream_closed(self) -> None:
        # Handle close.
        pass

def subscribeIoTCore():
    qos = QOS.AT_MOST_ONCE

    request = SubscribeToIoTCoreRequest()
    request.topic_name = "ppe/camera/" + device_id
    request.qos = qos
    handler = IoTCoreStreamHandler()
    operation = ipc_in_client.new_subscribe_to_iot_core(handler)
    future = operation.activate(request)

    try:
        future.result(TIMEOUT)
        print('Successfully subscribed to topic: ' + inference_result_topic)
    except concurrent.futures.TimeoutError as e:
        print('Timeout occurred while subscribing to topic: ' + inference_result_topic, file=sys.stderr)
        raise e
    except UnauthorizedError as e:
        print('Unauthorized error while subscribing to topic: ' + inference_result_topic, file=sys.stderr)
        raise e
    except Exception as e:
        print('Exception while subscribing to topic: ' + inference_result_topic, file=sys.stderr)
        raise e

# using subprocess and pipe to fetch frame data
p = subprocess.Popen(command, stdin=subprocess.PIPE)
subscribe()
subscribeIoTCore()
last = datetime.datetime.now()
first = True

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        print("frame read failed")
        break

    mid = str(uuid.uuid4())

    now = datetime.datetime.now()
    if (now - last).total_seconds() > 1 or first:
        source = '{0}/{1}.jpg'.format(ROOT / 'data/images', mid)
        cv2.imwrite(source, frame)
        notificaitonList = []
        notification = {}
        message = {}
        message['mid'] = mid
        message['source'] = source
        print('----- stream_out_message ----- ' + stream_out_message)
        try:
            condition_obj.acquire()
            publish(json.dumps(message), inference_topic)
            
            while len(outputList) < inference_count:
                value = condition_obj.wait(2)
                if value:
                    print(outputList)
                else:
                    print("Waiting timeout")
                    os.remove(source)

            notification['source'] = source
            notification['results'] = []

            for output in outputList:
                # print('output - {0}'.format(output))
                result = {}
                result['type'] = 'mask'
                result['result'] = json.dumps(output) 
                notification['results'].append(result)

                labels = []

                for line in output:
                    labels.append(str(line))
                    ixywh = line.split(' ')
                    clz = int(ixywh[0])
                    x = float(ixywh[1])
                    y = float(ixywh[2])
                    w = float(ixywh[3])
                    h = float(ixywh[4])
                    # print(frame.shape)
                    pt1 = (round((x - w / 2) * frame.shape[1]), round((y - h / 2) * frame.shape[0])) 
                    pt2 = (round((x + w / 2) * frame.shape[1]), round((y + h / 2) * frame.shape[0]))
                    cv2.rectangle(frame, pt1, pt2, (255, 0, 0), 3)
                    if clz == 0:
                        text = 'mask'
                        color = (0, 255, 0)
                    else:
                        text = 'no mask'
                        color = (0, 0, 255)
                    cv2.putText(frame, text, pt1, cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2, cv2.LINE_AA)

            if len(outputList) > 0:   
                labeled_source = '{0}/{1}.jpg'.format(ROOT / 'data/images', 'labeled_' + mid)
                cv2.imwrite(labeled_source, frame)
                notification['labeled_source'] = labeled_source

                labeled_text_source = '{0}/{1}.txt'.format(ROOT / 'data/images', mid)
                with open(labeled_text_source, 'w') as f:
                    for label in labels:
                        f.writelines(label)
                notification['labeled_text_source'] = labeled_text_source
                
                publish(json.dumps(notification), notification_topic)
            
            last = now
            first = False

        except:
            traceback.print_exc()
        finally:
            condition_obj.release()


        #     if value:
        #         print('output - {0}'.format(output))
        #         notification['type'] = 'mask'
        #         notification['source'] = source
        #         notification['result'] = json.dumps(output)

        #         labels = []

        #         for line in output:
        #             labels.append(str(line))
        #             ixywh = line.split(' ')
        #             clz = int(ixywh[0])
        #             x = float(ixywh[1])
        #             y = float(ixywh[2])
        #             w = float(ixywh[3])
        #             h = float(ixywh[4])
        #             print(frame.shape)
        #             pt1 = (round((x - w / 2) * frame.shape[1]), round((y - h / 2) * frame.shape[0])) 
        #             pt2 = (round((x + w / 2) * frame.shape[1]), round((y + h / 2) * frame.shape[0]))
        #             cv2.rectangle(frame, pt1, pt2, (255, 0, 0), 3)
        #             if clz == 0:
        #                 text = 'mask'
        #                 color = (0, 255, 0)
        #             else:
        #                 text = 'no mask'
        #                 color = (0, 0, 255)
        #             cv2.putText(frame, text, pt1, cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2, cv2.LINE_AA)
                
        #         labeled_source = '{0}/{1}.jpg'.format(ROOT / 'data/images', 'labeled_' + mid)
        #         cv2.imwrite(labeled_source, frame)
        #         notification['labeled_source'] = labeled_source

        #         labeled_text_source = '{0}/{1}.txt'.format(ROOT / 'data/images', mid)
        #         with open(labeled_text_source, 'w') as f:
        #             for label in labels:
        #                 f.writelines(label)
        #         notification['labeled_text_source'] = labeled_text_source
                
        #         publish(json.dumps(notification), notification_topic)
        #     else:
        #         print("Waiting timeout")
        #         os.remove(source)
        #     last = now
        #     first = False
        # except:
        #     traceback.print_exc()
        # finally:
        #     condition_obj.release()
            # os.remove(source)

    # write to pipe
    if stream_out_message == 'on':
        p.stdin.write(frame.tobytes())
